﻿namespace WildFarm.Models.Animals.Interfaces
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}
