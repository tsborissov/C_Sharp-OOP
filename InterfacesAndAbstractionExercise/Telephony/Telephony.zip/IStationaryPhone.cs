﻿namespace Telephony
{
    public interface IStationaryPhone
    {
        public void Dial(string number);
    }
}
