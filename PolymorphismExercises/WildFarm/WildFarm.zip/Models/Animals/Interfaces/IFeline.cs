﻿namespace WildFarm.Models.Animals.Interfaces
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
