﻿namespace RobotService.Utilities.Enums
{
    public enum RobotTypes
    {
        PetRobot = 1,
        HouseholdRobot = 2,
        WalkerRobot = 3
    }
}
