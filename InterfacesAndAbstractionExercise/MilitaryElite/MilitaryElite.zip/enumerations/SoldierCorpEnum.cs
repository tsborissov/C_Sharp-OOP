﻿namespace MilitaryElite.enumerations
{
    public enum SoldierCorpEnum
    {
        Airforces = 1,
        Marines = 2
    }
}
