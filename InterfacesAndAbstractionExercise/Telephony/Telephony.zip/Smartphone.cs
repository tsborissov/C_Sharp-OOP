﻿using System;
using System.Text.RegularExpressions;

namespace Telephony
{
    public class Smartphone : ISmartphone
    {
        public void Browse(string site)
        {
            if (ValidateSite(site))
            {
                System.Console.WriteLine($"Browsing: {site}!");
            }
        }

        

        public void Call(string number)
        {
            if (ValidateNumber(number))
            {
                System.Console.WriteLine($"Calling... {number}");
            }
        }

        private bool ValidateSite(string site)
        {
            string pattern = @"[0-9]{1,}";

            Regex regex = new Regex(pattern);

            if (regex.IsMatch(site))
            {
                Console.WriteLine("Invalid URL!");

                return false;
            }

            return true;
        }

        private bool ValidateNumber(string number)
        {
            string pattern = @"[0-9]{10}";

            Regex regex = new Regex(pattern);

            if (!regex.IsMatch(number))
            {
                Console.WriteLine("Invalid number!");

                return false;
            }

            return true;
        }
    }
}
