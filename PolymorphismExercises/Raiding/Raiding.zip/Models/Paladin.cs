﻿namespace Raiding.Models
{
    public class Paladin : Hero
    {
        public Paladin(string name, int power)
            : base(name, power)
        {
        }
    }
}
