﻿namespace MilitaryElite.interfaces
{
    public interface ISpy
    {
        public int SpyCodeNumber { get; }
    }
}
