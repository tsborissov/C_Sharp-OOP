﻿namespace Vehicles
{
    public abstract class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;

        protected Vehicle(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity
        {
            get { return this.fuelQuantity; }
            protected set { this.fuelQuantity = value; }
        }

        public double FuelConsumption
        {
            get { return this.fuelConsumption; }
            protected set { this.fuelConsumption = value; }
        }

        public bool Drive(double distance)
        {
            bool canDrive = this.FuelQuantity - this.fuelConsumption * distance >= 0;

            if (canDrive)
            {
                this.fuelQuantity -= this.FuelConsumption * distance;

                return true;
            }

            return false;
        }

        public virtual void Refuel(double fuel)
        {
            this.FuelQuantity += fuel;
        }
    }
}
