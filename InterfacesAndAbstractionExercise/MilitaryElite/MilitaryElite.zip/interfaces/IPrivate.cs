﻿namespace MilitaryElite.interfaces
{
    public interface IPrivate
    {
        public decimal Salary { get; }
    }
}
