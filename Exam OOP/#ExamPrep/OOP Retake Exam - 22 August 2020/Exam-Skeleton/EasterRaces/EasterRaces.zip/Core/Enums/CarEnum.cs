﻿namespace EasterRaces.Core.Enums
{
    public enum CarEnum
    {
        Muscle = 1,
        Sports = 2
    }
}
