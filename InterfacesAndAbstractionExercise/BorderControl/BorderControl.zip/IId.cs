﻿namespace BorderControl
{
    interface IId
    {
        public string Id { get; }

    }
}
