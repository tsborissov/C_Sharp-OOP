﻿using MilitaryElite.enumerations;

namespace MilitaryElite.interfaces
{
    public interface ISpecialisedSoldier
    {
        public string SoldierCorp { get; }
    }
}
