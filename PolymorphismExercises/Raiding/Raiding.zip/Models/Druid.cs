﻿namespace Raiding.Models
{
    public class Druid : Hero
    {
        public Druid(string name, int power)
            : base(name, power)
        {
        }
    }
}
