﻿namespace Vehicles
{
    public class Truck : Vehicle
    {
        private const double AirCondAdditionalConsumption = 1.6;
        
        public Truck(double fuelQuantity, double fuelConsumtion)
            : base(fuelQuantity, fuelConsumtion)
        {
            this.FuelConsumption += AirCondAdditionalConsumption;
        }

        public override void Refuel(double fuel)
        {
            fuel *= 0.95;
            base.Refuel(fuel);
        }
    }
}
