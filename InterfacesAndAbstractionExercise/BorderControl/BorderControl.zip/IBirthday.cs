﻿namespace BorderControl
{
    public interface IBirthdate
    {
        public string Birthdate { get; }
    }
}
