﻿namespace WildFarm.Models.Animals.Interfaces
{
    public interface ISoundProducable
    {
        public string ProduceSound();
    }
}
