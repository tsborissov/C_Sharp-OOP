﻿namespace MilitaryElite.enumerations
{
    public enum MissionStateEnum
    {
        inProgress = 1,
        Finished = 2
    }
}
