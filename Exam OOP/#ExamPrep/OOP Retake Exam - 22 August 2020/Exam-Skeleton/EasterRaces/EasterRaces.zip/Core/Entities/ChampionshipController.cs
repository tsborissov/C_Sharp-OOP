﻿using EasterRaces.Core.Contracts;
using EasterRaces.Repositories.Entities;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using EasterRaces.Utilities.Messages;
using EasterRaces.Models.Drivers.Entities;
using EasterRaces.Core.Enums;
using EasterRaces.Models.Cars.Contracts;
using EasterRaces.Models.Cars.Entities;
using EasterRaces.Models.Drivers.Contracts;
using EasterRaces.Models.Races.Contracts;
using EasterRaces.Models.Races.Entities;

namespace EasterRaces.Core.Entities
{
    public class ChampionshipController : IChampionshipController
    {
        private readonly DriverRepository drivers;
        private readonly CarRepository cars;
        private readonly RaceRepository races;

        public ChampionshipController()
        {
            this.drivers = new DriverRepository();
            this.cars = new CarRepository();
            this.races = new RaceRepository();
        }
        
        public string AddCarToDriver(string driverName, string carModel)
        {
            IDriver targetDriver = this.drivers.GetByName(driverName);

            if (targetDriver == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.DriverNotFound, driverName));
            }

            ICar targetCar = this.cars.GetByName(carModel);

            if (targetCar == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.CarNotFound, carModel));
            }

            targetDriver.AddCar(targetCar);

            return string.Format(OutputMessages.CarAdded, driverName, carModel);
        }

        public string AddDriverToRace(string raceName, string driverName)
        {
            IRace targetRace = this.races.GetByName(raceName);

            if (targetRace == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceNotFound, raceName));
            }

            IDriver targetDriver = this.drivers.GetByName(driverName);

            if (targetDriver == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.DriverNotFound, driverName));
            }

            targetRace.AddDriver(targetDriver);

            return string.Format(OutputMessages.DriverAdded, driverName, raceName);
        }

        public string CreateCar(string type, string model, int horsePower)
        {
            if (this.cars.GetAll().Any(x => x.Model == model))
            {
                throw new ArgumentException(string.Format(ExceptionMessages.CarExists, model));
            }

            ICar currentCar = null;

            if (Enum.TryParse(type, out CarEnum carTypeEnum))
            {
                switch (carTypeEnum)
                {
                    case CarEnum.Muscle:
                        currentCar = new MuscleCar(model, horsePower);
                        break;
                    case CarEnum.Sports:
                        currentCar = new SportsCar(model, horsePower);
                        break;
                }
            }

            this.cars.Add(currentCar);

            return string.Format(OutputMessages.CarCreated, type, model);
        }

        public string CreateDriver(string driverName)
        {
            if (this.drivers.GetAll().Any(x => x.Name == driverName))
            {
                throw new ArgumentException(string.Format(ExceptionMessages.DriversExists, driverName));
            }

            this.drivers.Add(new Driver(driverName));

            return string.Format(OutputMessages.DriverCreated, driverName);
        }

        public string CreateRace(string name, int laps)
        {
            if (this.races.GetAll().Any(x => x.Name == name))
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceExists, name));
            }

            this.races.Add(new Race(name, laps));

            return string.Format(OutputMessages.RaceCreated, name);
        }

        public string StartRace(string raceName)
        {
            IRace targetRace = this.races.GetByName(raceName);

            if (targetRace == null)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceNotFound, raceName));
            }

            if (targetRace.Drivers.Count < 3)
            {
                throw new InvalidOperationException(string.Format(ExceptionMessages.RaceInvalid, raceName, 3));
            }

            int laps = targetRace.Laps;

            List<KeyValuePair<string, double>> driversRanking = new List<KeyValuePair<string, double>>();

            foreach (var driver in targetRace.Drivers)
            {
                double points = driver.Car.CalculateRacePoints(laps);
                string driverName = driver.Name;

                driversRanking.Add(new KeyValuePair<string, double>(driverName, points));
            }

            driversRanking = driversRanking.OrderByDescending(x => x.Value).ToList();

            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Driver {driversRanking[0].Key} wins {targetRace.Name} race.");
            sb.AppendLine($"Driver {driversRanking[1].Key} is second in {targetRace.Name} race.");
            sb.AppendLine($"Driver {driversRanking[2].Key} is third in {targetRace.Name} race.");

            this.races.Remove(targetRace);

            return sb.ToString().TrimEnd();
        }
    }
}
