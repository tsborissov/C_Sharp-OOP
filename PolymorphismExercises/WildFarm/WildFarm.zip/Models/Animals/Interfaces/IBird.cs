﻿namespace WildFarm.Models.Animals.Interfaces
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
